package com.facebook.react;

import org.gradle.api.Plugin;
import org.gradle.api.Project;

public class ReactNativeGradlePlugin implements Plugin<Project> {
    @Override
    public void apply(Project project) {
        // Plugin mínimo — não precisa implementar nada
    }
}
