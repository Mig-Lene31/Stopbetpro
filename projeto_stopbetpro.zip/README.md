StopBet Pro - projeto gerado automaticamente
Passos rápidos (Termux):
1) cd ~/StopBetPro_project
2) npm install
3) Para compilar no Codemagic: comitar o repositório e configurar keystore e variáveis no Codemagic.
IMPORTANTE: Para testar no aparelho real, instalar APK assinado e ativar Accessibility service em Configurações > Acessibilidade > StopBet Pro.
